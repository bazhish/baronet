def janela_de_status():
    return {
        "nome": None,
        "nível": None,
        "dano": None,
        "velocidade": None,
        "defesa": None,
        "vida": None,
        "arma": None,
        "experiencia": None,
        "classe": None
    }